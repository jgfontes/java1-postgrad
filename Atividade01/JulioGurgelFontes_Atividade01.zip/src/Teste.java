public class Teste {
    public static void main(String[] args) {
        //Test constructor without inputs
        Veiculo noInputsVeiculo = new Veiculo();
        System.out.println(noInputsVeiculo);

        //Test constructor with inputs
        Veiculo FordKa = new Veiculo(
                "ABC-1234",
                "Ford",
                "Ka",
                "Preto",
                200,
                4,
                new Motor(
                        6,
                        85)
        );
        System.out.println(FordKa);

        //Using setters to store values of noInputsVeiculo
        noInputsVeiculo.setPlaca("DEF-5678");
        noInputsVeiculo.setMarca("Chevrolet");
        noInputsVeiculo.setModelo("Camaro");
        noInputsVeiculo.setCor("Amarelo");
        noInputsVeiculo.setVelocMax(300);
        noInputsVeiculo.setQtdRodas(4);
        noInputsVeiculo.setMotor(new Motor(
                6,
                467
        ));

        //Using getters to print values of noInputsVeiculo
        System.out.println(noInputsVeiculo.getPlaca());
        System.out.println(noInputsVeiculo.getMarca());
        System.out.println(noInputsVeiculo.getModelo());
        System.out.println(noInputsVeiculo.getCor());
        System.out.println(noInputsVeiculo.getVelocMax());
        System.out.println(noInputsVeiculo.getQtdRodas());
        System.out.println(noInputsVeiculo.getMotor());
    }
}
